*字典放在dictionnary文件夹中

!!!（conf.txt）配置文件介绍：!!!<<<大多参数在此设置
*url
*inject-position：注入位置 cookie,url,user-agent,body(post模式下)
*method:get,post
dictionary： 字典名,加载多个字典用";"分开,末尾不要加";"
user-agent： 默认user-agent
post-body： post模式下的包体
cookie：cookie
*for-time: 发包间隔
*delay-time：响应等待时间
introduction：介绍
my_payload：是否装载自己的编辑方式（需要在self_edit.py文件中编写代码）

作者：amos
blog: https://amos39.io/blog
项目地址：https://amos39.github.io/blog/server/project/projectind.html
