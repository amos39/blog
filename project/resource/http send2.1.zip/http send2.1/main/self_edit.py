def my_payload(payload):





    
    #edit_payload为修饰后的语句
    edit_payload=payload+'#'

    return edit_payload