def introd():
    try:
        with open('READ ME.txt','r') as file:
            print(file.read())
            print("如果你想启动时关闭此介绍，可更改配置文件中的introduction选项")
    except:
        print("README文件不存在！")
    print("欢迎使用自助发包脚本(http_send)2.0")
    print("author by amos39")
    return 0